package com.rafcoding.projectjssv2.activity;

import android.app.Activity;

public class DaftarAkunActivity extends Activity {
}
