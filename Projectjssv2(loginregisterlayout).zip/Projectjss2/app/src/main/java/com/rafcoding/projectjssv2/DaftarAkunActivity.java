package com.rafcoding.projectjssv2;

import android.app.Activity;

public class DaftarAkunActivity extends Activity {
}
