package com.rafcoding.projectjssv2.model;

public interface coba {
}
