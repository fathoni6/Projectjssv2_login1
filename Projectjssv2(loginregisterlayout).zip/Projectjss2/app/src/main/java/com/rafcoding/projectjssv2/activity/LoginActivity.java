package com.rafcoding.projectjssv2.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

public class LoginActivity extends Activity {
}

