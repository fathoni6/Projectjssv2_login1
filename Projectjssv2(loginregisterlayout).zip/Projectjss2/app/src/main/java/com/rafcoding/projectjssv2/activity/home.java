package com.rafcoding.projectjssv2.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.rafcoding.projectjssv2.R;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}